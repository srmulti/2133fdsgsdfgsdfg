2016-02-06  Louis Brauer <louis77@mac.com>

  # 1.1

    * requests.lua (make_request): Added HTTPS support using LuaSec
